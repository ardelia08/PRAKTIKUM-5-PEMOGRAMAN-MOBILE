package com.example.elma_039_prak5

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
