
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Biodata Mahasiswa',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF00897B),
        fontFamily: 'Roboto',
      ),
      home: const HalamanBiodata(),
    );
  }
}

class HalamanBiodata extends StatefulWidget {
  const HalamanBiodata({super.key});

  @override
  State<HalamanBiodata> createState() => _HalamanBiodataState();
}

class _HalamanBiodataState extends State<HalamanBiodata> {

  final _formKey = GlobalKey<FormState>();

  final namaCtrl = TextEditingController();
  final emailCtrl = TextEditingController();
  final hpCtrl = TextEditingController();

  bool setuju = false;
  bool cekPersetujuan = false;

  @override
  void dispose() {
    namaCtrl.dispose();
    emailCtrl.dispose();
    hpCtrl.dispose();
    super.dispose();
  }

  // FUNGSI SIMPAN
  void simpanBiodata() {
    setState(() {
      cekPersetujuan = true;
    });

    if (!_formKey.currentState!.validate()) {
      return;
    }

    if (!setuju) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Silakan centang persetujuan terlebih dahulu!',
          ),
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }

    String ringkasan =
        'BIODATA BERHASIL DISIMPAN\n'
        'Nama: ${namaCtrl.text.trim()}\n'
        'Email: ${emailCtrl.text.trim()}\n'
        'No. HP: ${hpCtrl.text.trim()}';

    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(ringkasan),
          backgroundColor: const Color(0xFF00796B),
          duration: const Duration(seconds: 7),
          behavior: SnackBarBehavior.floating,
          margin: const EdgeInsets.all(12),
        ),
      );
  }

  // STYLE INPUT
  InputDecoration inputStyle({
    required String label,
    required String hint,
    required IconData icon,
  }) {
    return InputDecoration(
      labelText: label,
      hintText: hint,
      prefixIcon: Icon(icon, color: const Color(0xFF00897B)),
      filled: true,
      fillColor: const Color(0xFFF4F8F7),
      contentPadding: const EdgeInsets.symmetric(
        horizontal: 16,
        vertical: 18,
      ),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide.none,
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(
          color: Color(0xFFE0EBE8),
        ),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(
          color: Color(0xFF00897B),
          width: 1.5,
        ),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: Colors.red),
      ),
      focusedErrorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(
          color: Colors.red,
          width: 1.5,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF1F6F5),

      body: SingleChildScrollView(
        child: Column(
          children: [

            // HEADER GRADASI
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(24, 60, 24, 55),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Color(0xFF00897B),
                    Color(0xFF26A69A),
                    Color(0xFF4DB6AC),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(35),
                  bottomRight: Radius.circular(35),
                ),
              ),

              child: Column(
                children: [

                  // ICON PROFIL
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.20),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      Icons.person_add_alt_1,
                      color: Colors.white,
                      size: 55,
                    ),
                  ),

                  const SizedBox(height: 18),

                  const Text(
                    'BIODATA MAHASISWA',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1,
                    ),
                  ),

                  const SizedBox(height: 8),

                  const Text(
                    'Lengkapi informasi diri Anda',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                    ),
                  ),

                ],
              ),
            ),

            // FORM CARD
            Transform.translate(
              offset: const Offset(0, -28),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),

                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(22),

                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(22),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.teal.withValues(alpha: 0.10),
                        blurRadius: 20,
                        offset: const Offset(0, 8),
                      ),
                    ],
                  ),

                  child: Form(
                    key: _formKey,

                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [

                        const Text(
                          'Formulir Data Diri',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Color(0xFF263D3A),
                          ),
                        ),

                        const SizedBox(height: 6),

                        const Text(
                          'Silakan isi semua kolom berikut.',
                          style: TextStyle(
                            fontSize: 13,
                            color: Colors.grey,
                          ),
                        ),

                        const SizedBox(height: 25),

                        // NAMA
                        const Text(
                          'Nama Lengkap',
                          style: TextStyle(
                            fontWeight: FontWeight.w600,
                          ),
                        ),

                        const SizedBox(height: 9),

                        TextFormField(
                          controller: namaCtrl,
                          textCapitalization: TextCapitalization.words,
                          decoration: inputStyle(
                            label: 'Nama',
                            hint: 'Masukkan nama lengkap',
                            icon: Icons.person_outline,
                          ),
                          validator: (value) {
                            if (value == null ||
                                value.trim().isEmpty) {
                              return 'Nama wajib diisi';
                            }
                            return null;
                          },
                        ),

                        const SizedBox(height: 20),

                        // EMAIL
                        const Text(
                          'Alamat Email',
                          style: TextStyle(
                            fontWeight: FontWeight.w600,
                          ),
                        ),

                        const SizedBox(height: 9),

                        TextFormField(
                          controller: emailCtrl,
                          keyboardType: TextInputType.emailAddress,
                          decoration: inputStyle(
                            label: 'Email',
                            hint: 'contoh@gmail.com',
                            icon: Icons.email_outlined,
                          ),
                          validator: (value) {
                            if (value == null ||
                                value.trim().isEmpty) {
                              return 'Email wajib diisi';
                            }

                            if (!value.contains('@')) {
                              return 'Email harus mengandung @';
                            }

                            return null;
                          },
                        ),

                        const SizedBox(height: 20),

                        // NOMOR HP
                        const Text(
                          'Nomor Handphone',
                          style: TextStyle(
                            fontWeight: FontWeight.w600,
                          ),
                        ),

                        const SizedBox(height: 9),

                        TextFormField(
                          controller: hpCtrl,
                          keyboardType: TextInputType.phone,
                          decoration: inputStyle(
                            label: 'Nomor HP',
                            hint: '085123456789',
                            icon: Icons.phone_android,
                          ),
                          validator: (value) {
                            if (value == null ||
                                value.trim().isEmpty) {
                              return 'Nomor HP wajib diisi';
                            }

                            if (!RegExp(r'^\d{10,}$')
                                .hasMatch(value.trim())) {
                              return 'Nomor HP minimal 10 digit angka';
                            }

                            return null;
                          },
                        ),

                        const SizedBox(height: 20),

                        // CHECKBOX PERSETUJUAN
                        Container(
                          decoration: BoxDecoration(
                            color: const Color(0xFFF4F8F7),
                            borderRadius: BorderRadius.circular(12),
                          ),

                          child: CheckboxListTile(
                            value: setuju,
                            activeColor: const Color(0xFF00897B),
                            controlAffinity:
                            ListTileControlAffinity.leading,
                            contentPadding: const EdgeInsets.symmetric(
                              horizontal: 8,
                            ),
                            title: const Text(
                              'Saya menyetujui syarat dan ketentuan',
                              style: TextStyle(fontSize: 13),
                            ),
                            onChanged: (value) {
                              setState(() {
                                setuju = value ?? false;
                              });
                            },
                          ),
                        ),

                        if (cekPersetujuan && !setuju)
                          const Padding(
                            padding: EdgeInsets.only(top: 6, left: 8),
                            child: Text(
                              'Persetujuan wajib dicentang',
                              style: TextStyle(
                                color: Colors.red,
                                fontSize: 12,
                              ),
                            ),
                          ),

                        const SizedBox(height: 25),

                        // TOMBOL SIMPAN
                        SizedBox(
                          width: double.infinity,
                          height: 55,

                          child: ElevatedButton.icon(
                            onPressed: simpanBiodata,
                            icon: const Icon(Icons.save_outlined),
                            label: const Text(
                              'SIMPAN BIODATA',
                              style: TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 0.5,
                              ),
                            ),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFF00897B),
                              foregroundColor: Colors.white,
                              elevation: 2,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(14),
                              ),
                            ),
                          ),
                        ),

                      ],
                    ),
                  ),
                ),
              ),
            ),

            // FOOTER
            const Padding(
              padding: EdgeInsets.only(
                bottom: 25,
                top: 0,
              ),
              child: Text(
                'Praktikum Pemrograman Mobile',
                style: TextStyle(
                  fontSize: 12,
                  color: Colors.grey,
                ),
              ),
            ),

          ],
        ),
      ),
    );
  }
}
